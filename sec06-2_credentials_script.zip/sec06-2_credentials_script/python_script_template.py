#!/usr/bin/env python3

import sys

def my_function():
    pass


def main():
    """
    This script ...
    """


# Standard call to the main() function.
if __name__ == '__main__':
    print(f"List of command line arguments passed to the script.\n{sys.argv}\nThe first element is always the script name.")
    main()
